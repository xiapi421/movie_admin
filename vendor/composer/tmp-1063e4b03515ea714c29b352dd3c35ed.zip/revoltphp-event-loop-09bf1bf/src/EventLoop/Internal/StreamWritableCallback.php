<?php

declare(strict_types=1);

namespace Revolt\EventLoop\Internal;

/** @internal */
final class StreamWritableCallback extends StreamCallback
{
}
