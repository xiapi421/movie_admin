<?php
define('STUB_DIR', realpath(__DIR__ . '/stub'));
