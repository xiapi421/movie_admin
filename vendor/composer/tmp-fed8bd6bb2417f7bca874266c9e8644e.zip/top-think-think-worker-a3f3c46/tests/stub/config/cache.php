<?php
return [
    'default' => 'file',
    'stores'  => [
        'file' => [
            'type' => 'File',
        ],
    ]
];
