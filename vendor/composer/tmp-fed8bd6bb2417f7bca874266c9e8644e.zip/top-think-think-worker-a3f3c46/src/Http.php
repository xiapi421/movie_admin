<?php

namespace think\worker;

class Http extends \think\Http
{

    protected function loadMiddleware(): void
    {

    }

    protected function loadRoutes(): void
    {

    }
}
